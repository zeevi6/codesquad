/**
 * Created by Joy on 2017. 3. 29..
 */

module.exports = {
  mysql: {
    host: '192.168.56.105',
    port: 3306,
    user: 'hong',
    password: 'hong123',
    database: 'todoist'
  }
}

