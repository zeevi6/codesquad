/**
 * Created by Joy on 2017. 3. 29..
 */

const env = process.env.NODE_ENV || 'development';
const config = require(`./${env}`);

module.exports = config;
