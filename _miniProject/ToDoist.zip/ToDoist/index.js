const express = require('express');
const mysql = require('mysql');

const router = require('./routes/route');
const config = require('./config');

const app = express();
const connection = mysql.createConnection(config.mysql);

app.use('/', router);

app.listen(3000, function () {
  connection.connect();
  console.log('Example app listening on port 3000!');
});
