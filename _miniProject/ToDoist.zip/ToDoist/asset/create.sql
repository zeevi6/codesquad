-- DROP TABLE --
DROP TABLE IF EXISTS task;
DROP TABLE IF EXISTS label;
DROP TABLE IF EXISTS task_label_mapping;


-- CREATE TABLE --
CREATE TABLE task (
	task_id INTEGER(32) NOT NULL AUTO_INCREMENT,
	task_text VARCHAR(255) NOT NULL,
	task_status VARCHAR(16) NOT NULL,
	PRIMARY KEY(task_id)
);

CREATE TABLE label (
	label_id INTEGER(32) NOT NULL AUTO_INCREMENT,
	label_text VARCHAR(255) NOT NULL,
	label_color VARCHAR(32) NOT NULL,
	PRIMARY KEY(label_id)
);

CREATE TABLE task_label_mapping (
	task_id INTEGER(32) NOT NULL,
	label_id INTEGER(32) NOT NULL,
	FOREIGN KEY(task_id) REFERENCES task(task_id) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY(label_id) REFERENCES label(label_id) ON UPDATE CASCADE ON DELETE CASCADE
);


-- INSERT CONTENTS --
INSERT INTO task(task_id, task_text, task_status) VALUES
(1, "Learning MySQL query ", "ACT"),
(2, "Eating bread", "DEL"),
(3, "Playing games", "DON"),
(4, "Cleaning my room", "DEL"),
(5, "Washing my shoes", "DON");

INSERT INTO label(label_id, label_text, label_color) VALUES
(1, "At home", "#D04B4B"),
(2, "At school", "#7579E5"),
(3, "At workplace", "#84E297"),
(4, "At club", "#B984E2");

INSERT INTO task_label_mapping(task_id, label_id) VALUES
(1, 1),
(1, 3),
(2, 3),
(2, 4),
(3, 3),
(4, 2),
(4, 4);

